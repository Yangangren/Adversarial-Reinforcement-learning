def mujoco():
    return dict(
        nsteps=2500,
        value_network='copy'
    )
